package com.lab.jweather.JModel;

public class JCloud {
    private int all;

    public JCloud(int all) {
        this.all = all;
    }

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}
