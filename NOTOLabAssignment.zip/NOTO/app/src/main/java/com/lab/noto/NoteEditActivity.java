package com.lab.noto;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;


import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;




public class NoteEditActivity extends AppCompatActivity {
    private EditText inputNote,inputTitle;
    private NotesD dao;
    private Note temp;
    public static final String NOTE_EXTRA_Key = "note_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences sharedPreferences = getSharedPreferences(MainActivity.APP_PREFERENCES, Context.MODE_PRIVATE);
        int theme = sharedPreferences.getInt(MainActivity.THEME_Key, R.style.AppTheme);
        setTheme(theme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_edit);

        inputTitle = findViewById(R.id.title1);
        inputNote= findViewById(R.id.inputnote);
        dao =  NotesDB.getInstance(this).notesDb();
        if (getIntent().getExtras() != null) {
            int id = getIntent().getExtras().getInt(NOTE_EXTRA_Key, 0);
            temp = dao.getNoteById(id);
            inputTitle.setText(temp.getTitle());
            inputNote.setText(temp.getNoteText());
        } else inputTitle.setFocusable(true);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.edit_note_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.save_note)
            onSaveNote();
        return super.onOptionsItemSelected(item);
    }

    private void onSaveNote() {
        String text = inputNote.getText().toString();
        String text2=inputTitle.getText().toString();
        if (!text.isEmpty() && !text2.isEmpty()) {
            long date = new Date().getTime();
            if (temp == null) {
                temp = new Note(text2,text, date);
                dao.insertNote(temp);
            } else {
                temp.setTitle(text2);
                temp.setNoteText(text);
                temp.setNoteDate(date);
                dao.updateNote(temp);
            }

            finish();
        }

    }
}
