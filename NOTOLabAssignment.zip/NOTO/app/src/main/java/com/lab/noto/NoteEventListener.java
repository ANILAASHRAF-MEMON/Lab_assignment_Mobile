package com.lab.noto;
import com.lab.noto.Note;
public interface NoteEventListener {


    void onNoteClick(Note note);


    void onNoteLongClick(Note note);
}
