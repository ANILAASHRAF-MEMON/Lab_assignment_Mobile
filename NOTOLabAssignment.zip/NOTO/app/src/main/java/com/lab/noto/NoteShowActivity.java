package com.lab.noto;



import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


public class NoteShowActivity extends AppCompatActivity {
    private TextView showNote,showTitle;
    private NotesD d;
    private Note temp;
    public static final String NOTE_EXTRA_Key = "note_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        SharedPreferences sharedPreferences = getSharedPreferences(MainActivity.APP_PREFERENCES, Context.MODE_PRIVATE);
        int theme = sharedPreferences.getInt(MainActivity.THEME_Key, R.style.AppTheme);
        setTheme(theme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_show);

        showTitle = findViewById(R.id.showT);
        showNote= findViewById(R.id.showN);
        d = (NotesD) NotesDB.getInstance(this).notesDb();
        if (getIntent().getExtras() != null) {
            int id = getIntent().getExtras().getInt(NOTE_EXTRA_Key, 0);
            temp = d.getNoteById(id);
            showTitle.setText(temp.getTitle());
            showNote.setText(temp.getNoteText());
        }

    }

}
