package com.lab.jreport;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {
TextView st,eid;
AppCompatButton bt,n;
    static String emailFromIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getSupportActionBar().hide();
        st=findViewById(R.id.ts);
        eid=findViewById(R.id.te);
        bt=findViewById(R.id.com);
      n=findViewById(R.id.h);
    emailFromIntent=getIntent().getStringExtra("Email");
        eid.setText(emailFromIntent);



       bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(HomeActivity.this,JGPSCameraActivity.class);
              i.putExtra("E",emailFromIntent);
                startActivity(i);
            }
        });
        n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(HomeActivity.this,JReportShowActivity.class);
                startActivity(i);
            }
        });



    }
}